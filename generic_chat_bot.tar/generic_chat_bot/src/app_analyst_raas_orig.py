# Public Docs: https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-analyst/rest-api
# This demo is not supported in SiS. You must run this streamlit locally.

import json
import re
from typing import Any, Generator, Iterator

import pandas
import pandas as pd
import requests
# import snowflake.connector
import sseclient
import streamlit as st
import spcs_helpers
from io import StringIO  
import time
from typing import Any
import pandas as pd



STAGE = "RAW_DATA"
FILE = "sales_semantic_model.yml"


# def get_conversation_history() -> list[dict[str, Any]]:
#     st.write("Current messages state:",st.session_state.messages)
#     messages = []
#     for msg in st.session_state.messages:
#         m: dict[str, Any] = {}
#         if msg["role"] == "user":
#             m["role"] = "user"
#         else:
#             m["role"] = "analyst"
#         text_content = "\n".join([c for c in msg["content"] if isinstance(c, str)])
#         m["content"] = [{"type": "text", "text": text_content}]
#         messages.append(m)
#     return messages




def get_conversation_history() -> list[dict[str, Any]]:
    # st.write("Current messages state:", st.session_state.messages)
    messages = []

    for msg in st.session_state.messages:
        role = msg.get("role", "user")
        message_content = []

        content_blocks = msg.get("content", [])

        for block in content_blocks:
            if isinstance(block, str):
                clean_text = block.strip()
                if clean_text:
                    message_content.append({"type": "text", "text": clean_text})

            elif isinstance(block, dict):
                # Only process 'text' type and skip 'sql' and 'dataframe'
                block_type = block.get("type", "text")
                if block_type in ["sql", "dataframe"]:
                    continue

                # Safely get text or value
                if "text" in block:
                    value = block["text"]
                elif "value" in block:
                    value = block["value"]
                else:
                    value = ""

                try:
                    clean_text = str(value).strip()
                except Exception:
                    clean_text = ""

                if clean_text:
                    message_content.append({"type": block_type, "text": clean_text})

        if message_content:
            messages.append({"role": role, "content": message_content})
    # st.write("messages prepared by get_conversation_history", messages)
    return messages





def send_message() -> requests.Response:
    """Calls the REST API and returns a streaming client."""
    request_body = {
        "messages": get_conversation_history(),
        "semantic_model_file": f"@{st.session_state.RAW_CONN.database}.{st.session_state.RAW_CONN.schema}.{STAGE}/{FILE}",
        "stream": True,
    }
    # st.write("Sending request body:", json.
    # dumps(request_body, indent=2))
    resp = requests.post(
        url=f"https://{st.session_state.RAW_CONN.host}/api/v2/cortex/analyst/message",
        json=request_body,
        headers={
            "Authorization": f'Snowflake Token="{st.session_state.RAW_CONN.rest.token}"',
            "Content-Type": "application/json",
        },
        stream=True,
    )
    if resp.status_code < 400:
        return resp  # type: ignore
    else:
        raise Exception(f"Failed request with status {resp.status_code}: {resp.text}")


def stream(events: Iterator[sseclient.Event]) -> Generator[Any, Any, Any]:
    prev_index = -1
    prev_type = ""
    prev_suggestion_index = -1
    while True:
        event = next(events, None)
        if not event:
            return
        data = json.loads(event.data)
        new_content_block = event.event != "message.content.delta" or data["index"] != prev_index

        if prev_type == "sql" and new_content_block:
            # Close sql markdown once sql section finishes.
            yield "\n```\n\n"
        match event.event:
            case "message.content.delta":
                match data["type"]:
                    case "sql":
                        if new_content_block:
                            # Add sql markdown when we enter a new sql block.
                            yield "```sql\n"
                        yield data["statement_delta"]
                    case "text":
                        yield data["text_delta"]
                    case "suggestions":
                        if new_content_block:
                            # Add a suggestions header when we enter a new suggestions block.
                            yield "\nHere are some example questions you could ask:\n\n"
                            yield "\n- "
                        elif (
                            prev_suggestion_index != data["suggestions_delta"]["index"]
                        ):
                            yield "\n- "
                        yield data["suggestions_delta"]["suggestion_delta"]
                        prev_suggestion_index = data["suggestions_delta"]["index"]
                prev_index = data["index"]
                prev_type = data["type"]
            case "status":
                st.session_state.status = data["status_message"]
                # We return here to allow the spinner to update with the latest status, but this method will be
                #  called again for the next iteration
                return
            case "error":
                st.session_state.error = data
                return



def display_df(df: pd.DataFrame) -> None:
    if len(df.index) >= 1:
        data_tab, line_tab, bar_tab = st.tabs(["Data", "Line Chart", "Bar Chart"])
        data_tab.dataframe(df)

        index_col = df.columns[0]
        default_cols = df.columns.tolist()

        def render_chart(tab, chart_type: str, selected_cols: list):
            """Render chart based on selected columns."""
            if selected_cols:
                try:
                    chart_df = df[[index_col] + selected_cols].set_index(index_col)
                    if chart_type == "line":
                        tab.line_chart(chart_df)
                    else:
                        tab.bar_chart(chart_df)
                except Exception as e:
                    tab.warning(f"Could not render {chart_type} chart: {e}")
            else:
                tab.info(f"Please select at least one numeric column for the {chart_type} chart.")

        # Handle charts based on the number of columns
        if len(df.columns) == 2:  # Exactly 2 columns (year and total_revenue)
            chart_df = df.set_index(index_col)
            with line_tab:
                st.line_chart(chart_df)
            with bar_tab:
                st.bar_chart(chart_df)
        # elif len(df.columns) <= 3:
        #     chart_df = df.set_index(index_col)
        #     with line_tab:
        #         st.line_chart(chart_df)
        #     with bar_tab:
        #         st.bar_chart(chart_df)
        # else:
        #     # User selects columns for line chart
        #     with line_tab:
        #         st.markdown("**Select columns to plot (Line Chart):**")
        #         selected_line_cols = st.multiselect(
        #             "Line Chart Columns", default_cols, default=default_cols, key="line_cols"
        #         )
        #         render_chart(line_tab, "line", selected_line_cols)

        #     # User selects columns for bar chart
        #     with bar_tab:
        #         st.markdown("**Select columns to plot (Bar Chart):**")
        #         selected_bar_cols = st.multiselect(
        #             "Bar Chart Columns", default_cols, default=default_cols, key="bar_cols"
        #         )
        #         render_chart(bar_tab, "bar", selected_bar_cols)
    else:
        st.dataframe(df)



        

def process_message(prompt: str) -> None:
    st.session_state.messages.append({"role": "user", "content": [prompt]})
    with st.chat_message("user"):
        st.markdown(prompt)

    accumulated_text = []
    with st.chat_message("assistant"):
        with st.spinner("Sending request..."):
            request_start_time = time.time()
            response = send_message()
            request_duration = time.time() - request_start_time

        with st.expander("Request Info"):
            st.markdown(
                f"""
                - `Request ID`: `{response.headers.get('X-Snowflake-Request-Id')}`  
                - `API Response Time`: `{request_duration:.2f} seconds`
                """
            )

        # Get the SSE stream from response
        events = sseclient.SSEClient(response).events()        
        streamed_text=""
        stream_start_time = time.time()        
        while st.session_state.status.lower() != "done":
            with st.spinner(st.session_state.status):
                for chunk in stream(events):
                    streamed_text+=chunk
        response_duration = time.time() - stream_start_time                    
        # Clean up text (remove awkward line breaks)
        cleaned_text = re.sub(r"\n\s*", " ", streamed_text).strip()

        # Extract SQL blocks
        sql_pattern = r"```sql\s*(.*?)\s*```"
        sql_blocks = re.findall(sql_pattern, cleaned_text, re.DOTALL | re.IGNORECASE)                
        
        # Remove SQL blocks from the text
        text_only = re.sub(
            r"(This is our interpretation of your question:\s*)",
            r"***\1***\n\n",  # bold + italic with newlines
            re.sub(sql_pattern, "", cleaned_text, flags=re.DOTALL),
            flags=re.IGNORECASE
        ).strip()

        # Show text output
        if text_only:
            lines = text_only.strip().split(" - ")
            formatted = "\n".join([f"- {line.strip()}" for line in lines if line.strip()])            
            st.markdown(formatted)
            accumulated_text.append({
                "type": "text",
                "text": formatted,
                "execution_time": response_duration
            })

        # Show SQL only inside expander        
        if sql_blocks:
            with st.expander("sql query"):
                st.code(sql_blocks[0], language="sql")      
            for sql_query in sql_blocks:                
                with st.spinner("Executing Query"):
                    sql_exec_start = time.time()
                    df = pd.read_sql(sql_query, st.session_state.RAW_CONN)
                    sql_exec_duration = time.time() - sql_exec_start
                    st.markdown(f"`SQL Execution Time`: `{sql_exec_duration:.2f} seconds`")                    
                    accumulated_text.append({
                        "type": "sql",
                        "text": sql_blocks[0],
                        "execution_time": sql_exec_duration
                    })
                    accumulated_text.append({
                        "type": "dataframe",
                        "text": df,
                        "execution_time": "None"
                    })
                    display_df(df)
        st.markdown(
            f"""
            🕒 **Total Timings:**  
            - `Request Time`: `{request_duration:.2f} seconds`              
            - `Response Stream Time`: `{response_duration:.2f} seconds`
            """
        )   
                                              

    st.session_state.status = "Interpreting question"    
    st.session_state.messages.append(
        {"role": "analyst", "content": accumulated_text}
    )


    


def show_conversation_history() -> None:
    for message in st.session_state.messages:
        chat_role = "assistant" if message["role"] == "analyst" else "user"
        with st.chat_message(chat_role):
            for content in message["content"]:
                if isinstance(content, dict) and content.get("type") == "text":
                    st.divider()
                    st.write(content["text"])
                    st.caption(f"🕓 Stream Time: {content.get('execution_time', 0):.2f} sec")
                elif isinstance(content, dict) and content.get("type") == "sql":
                    with st.expander("sql query"):
                        st.code(content["text"], language="sql")
                        st.caption(f"🕓 SQL Execution Time: {content.get('execution_time', 0):.2f} sec")
                elif isinstance(content, dict) and content.get("type") == "dataframe":
                    display_df(content["text"])
                elif isinstance(content, Exception):
                    st.error(f"Error while processing request:\n {content}", icon="🚨")
                else:
                    st.write(content)



def get_raw_connection(conn_name: str = "demo_account", conn_type: str = "snowflake"):
    """
    Returns the raw underlying connection object from Streamlit's st.connection().
    """
    conn = st.connection(conn_name, type=conn_type)
    raw_conn = getattr(conn, "_instance", None)
    if raw_conn is None:
        raise ValueError("Could not access underlying connection instance.")
    return raw_conn

def trim_and_get_unique(series: pd.Series) -> list:
    """Trims whitespace from each string in the series and returns unique values as a list."""
    return series.str.strip().unique().tolist()




try:
    raw_conn = get_raw_connection()
    token = raw_conn.rest.token
except Exception as e:
    st.error(f"Failed to access token: {e}")

if "RAW_CONN" not in st.session_state:
    st.session_state.RAW_CONN = get_raw_connection()    
    
# st.write(st.session_state.RAW_CONN.host)
# st.write(st.session_state.RAW_CONN.account)
# st.write(st.session_state.RAW_CONN.database)    
    
    
df=pd.read_sql("select current_user()",st.session_state.RAW_CONN)
current_user = df.iloc[0, 0]
login=f"""SELECT * FROM table(SNOWFLAKE.LOCAL.CORTEX_ANALYST_REQUESTS('FILE_ON_STAGE', '@{st.session_state.RAW_CONN.database}.{st.session_state.RAW_CONN.schema}.{STAGE}/{FILE}')) where user_name= '{current_user}'"""
df=pd.read_sql(login,st.session_state.RAW_CONN)
df["DATE"] = pd.to_datetime(df["TIMESTAMP"]).dt.date

# Step 2: Group by date
# grouped = df.groupby("DATE")["LATEST_QUESTION"].apply(list).reset_index()
# grouped = df.groupby("DATE")["LATEST_QUESTION"].unique().apply(list).reset_index()
grouped = df.groupby("DATE")["LATEST_QUESTION"].apply(trim_and_get_unique).reset_index()


with st.sidebar:
    # col1, col2 = st.columns([1, 3])
    # with col1:
    #     st.image("images/login.png", width=40)  # Smaller width for better alignment
    # with col2:
    st.markdown(f"**Logged in as : {current_user}**", unsafe_allow_html=True)

    st.markdown("### Previous questions")
    for _, row in grouped.iterrows():
        with st.expander(f"{row['DATE'].strftime('%d-%m-%Y')}"):
            for idx, question in enumerate(row["LATEST_QUESTION"]):
                st.markdown(f"- {question}")
                    

# --- Chat Area ---
st.title("💬 Chat with RAAS Sales Data AI")

# Initialize/reset session state
if st.button("Reset conversation") or "messages" not in st.session_state:
    st.session_state.messages = []
    st.session_state.status = "Interpreting question"
    st.session_state.error = None
    
show_conversation_history()    

# Check for user input from sidebar click or chat input
user_input = st.chat_input("What is your question?")
if user_input:    
    process_message(prompt=user_input)    





# markdown_style = """
# <style>
# .custom-popover {
#   position: fixed;
#   bottom: 10px;
#   left: 10px;
#   background-color: white;
#   border: 1px solid #ccc;
#   padding: 10px;
#   box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.1);
#   border-radius: 5px;
#   z-index: 1000; /* Ensure it's on top */
# }
# </style>
# """
# st.markdown(markdown_style, unsafe_allow_html=True)


# # Use a container to hold your chat elements
# popover_content = st.container()

# with st.popover("Ask Prism",):    
#     st.image("indigo_logo.png", caption="AI Assistant", width=500)
#     if user_input := st.chat_input("What is your question?"):
#         show_conversation_history()    
#         process_message(prompt=user_input)
    
# data_tabs = st.tabs(["Customers by BookingChannel","Customers by Contact"]) # Added tab
# with data_tabs[0]:
#     uniquekey=str(data_tabs[0])
#     df=dashboard.get_data(st.session_state.RAW_CONN)
#     start_date,end_date,chart_selection,agg_col_list, filter_col_list, filter_col_value = dashboard.get_widget(df,uniquekey)
#     df_filtered=dashboard.get_filter_data(df,start_date,end_date, filter_col_list, filter_col_value)
#     kpi1, kpi2, kpi3=dashboard.add_kpis()
#     dashboard.get_total(df_filtered,kpi1, kpi2, kpi3,uniquekey)
#     dashboard.display_chart(df_filtered,chart_selection)
#     dashboard.display_data(df_filtered, agg_col_list,uniquekey)    