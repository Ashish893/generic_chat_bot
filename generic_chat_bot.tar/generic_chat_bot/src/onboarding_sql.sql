USE ROLE ACCOUNTADMIN;

 

-- CREATE ROLE cortex_user_role;

 

CREATE DATABASE IF NOT EXISTS cortex_analyst_demo;

 

GRANT BIND SERVICE ENDPOINT ON ACCOUNT TO ROLE cortex_user_role;

 

CREATE COMPUTE POOL indigo_compute_pool_raas
  MIN_NODES = 1
  MAX_NODES = 1
  INSTANCE_FAMILY = CPU_X64_XS;

GRANT USAGE, MONITOR ON COMPUTE POOL indigo_compute_pool_raas TO ROLE cortex_user_role;

 

GRANT ROLE cortex_user_role TO USER ash_k;

 

USE ROLE cortex_user_role;


USE DATABASE cortex_analyst_demo;

-- USE WAREHOUSE cortex_analyst_wh;

 

use schema revenue_timeseries;

 

-- CREATE SCHEMA IF NOT EXISTS revenue_timeseries;

 

-- drop image repository indigo_chat_bot_img;

CREATE IMAGE REPOSITORY IF NOT EXISTS indigo_chat_bot_raas_img;

 

SHOW COMPUTE POOLS;

show warehouses;

 

SHOW IMAGE REPOSITORIES;

SHOW IMAGES IN IMAGE REPOSITORY indigo_chat_bot_raas_img;

 

SHOW STAGES in DATABASE;

 

DESCRIBE COMPUTE POOL indigo_compute_pool_raas;

 

ALTER COMPUTE POOL indigo_compute_pool_raas RESUME;  -- ensure the pool is started and active

 

ALTER COMPUTE POOL INDIGO_COMPUindigo_compute_pool_raasTE_POOL SUSPEND;  -- ensure the pool is started and active

alter service 

-- drop  SERVICE indigo_raas_service;

CREATE SERVICE indigo_raas_service
    IN COMPUTE POOL indigo_compute_pool_raas
      FROM SPECIFICATION $$
    spec:
      containers:
      - name: streamlit
        image: indigo-edhppprod.registry.snowflakecomputing.com/cortex_analyst_demo/revenue_timeseries/indigo_chat_bot_raas_img:v1      
        env:
          SNOWFLAKE_WAREHOUSE: DE_DS_WH         
      endpoints:
      - name: streamlit
        port: 8501
        public: true
    serviceRoles:
    - name: app
      endpoints:
      - streamlit
      $$
   MIN_INSTANCES=1
   MAX_INSTANCES=2;


   ALTER SERVICE indigo_raas_service
      FROM SPECIFICATION $$
    spec:
      containers:
      - name: streamlit
        image: indigo-edhppprod.registry.snowflakecomputing.com/cortex_analyst_demo/revenue_timeseries/indigo_chat_bot_raas_img:v11  
        env:
          SNOWFLAKE_WAREHOUSE: DE_DS_WH         
      endpoints:
      - name: streamlit
        port: 8501
        public: true
    serviceRoles:
    - name: app
      endpoints:
      - streamlit
      $$;

 

  

-- Step 4: Verify the Service

SHOW SERVICES;

DESC SERVICE indigo_raas_service;

SHOW SERVICE CONTAINERS IN SERVICE indigo_raas_service; -- review the status of individual containers

 

SHOW ENDPOINTS IN SERVICE indigo_raas_service;


SELECT SYSTEM$GET_SERVICE_STATUS('indigo_raas_service');


-- -- STEP 5: Create a Service Function (It's a UDF to associate with the service endpoint)

-- CREATE FUNCTION indigo_demo_service_udf (InputText varchar)

--   RETURNS varchar

--   SERVICE=indigo_demo_service

--   ENDPOINT=echoendpoint

--   AS '/echo';

 

-- -- Step 6: Use the service

-- SELECT indigo_demo_service_udf('hello!');

 

-- Using a Web Browser

-- step 1
docker build --rm --platform linux/amd64 -t indigo-edhppprod.registry.snowflakecomputing.com/cortex_analyst_demo/revenue_timeseries/indigo_chat_bot_raas_img:v16 .

-- step 2 
snow spcs image-registry token --connection mf20670.central-india.privatelink --format=JSON | docker login indigo-edhppprod.registry.snowflakecomputing.com --username chat_test_user --password Indigo@2025!

     
-- step 3
docker push indigo-edhppprod.registry.snowflakecomputing.com/cortex_analyst_demo/revenue_timeseries/indigo_chat_bot_raas_img:v16

--step 4

   ALTER SERVICE indigo_raas_service
      FROM SPECIFICATION $$
    spec:
      containers:
      - name: streamlit
        image: indigo-edhppprod.registry.snowflakecomputing.com/cortex_analyst_demo/revenue_timeseries/indigo_chat_bot_raas_img:v16
        env:
          SNOWFLAKE_WAREHOUSE: DE_DS_WH         
      endpoints:
      - name: streamlit
        port: 8501
        public: true
    serviceRoles:
    - name: app
      endpoints:
      - streamlit
      $$;


SHOW ENDPOINTS IN SERVICE indigo_raas_service;


SELECT SYSTEM$GET_SERVICE_STATUS('indigo_raas_service');

-- alter user chat_test_user set rsa_public_key='MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAu3BtOTYUoV+1U0N83w+J
-- t7FJvJ2/KZobhPzx22+cUkHDLGOwprndRSBuztcxsO1YIZaqA55fARlq2CL1FJET
-- y4vhVXGJYbTw9irQbKPNmNuae0thujwB+oNzHhkVBz0E+Zon7jWzNxlBpdgHbOMR
-- 3lex2zisc1R5AqVISkr6NuIskdRyJXdasCHozT9BWQtu2j7MfHBvsFoHnhtt5qSd
-- plndkCjT56I4/85KYH7bfXDqew0CdRdmnoMInKGclNEwPbM48zG9KXsjmPEVXl+J
-- oaZYISmnwgjrDscfkoIh1AmjiUAMCrvCbYgDxH1FNkCCWJ1avVnrrE3v4QCmRvMV
-- nwIDAQAB';