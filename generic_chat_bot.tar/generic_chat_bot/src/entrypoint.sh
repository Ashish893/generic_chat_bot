#!/bin/bash
python3 -m streamlit run app_analyst_raas.py --server.address=0.0.0.0 $@ 2>&1
