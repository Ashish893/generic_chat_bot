import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import base64
import os



    

    

def initialize_session_state():
    if 'messages' not in st.session_state:
        st.session_state.messages = []
        st.session_state.status = "Interpreting question"
        st.session_state.error = None
        st.session_state.form_submitted = ({}) 
        st.session_state.question = ""   

    if "show_text_input" not in st.session_state:
        st.session_state.show_text_input = False         
    if 'question' not in st.session_state:
        st.session_state.question = ""           

def clear_chat():
    st.session_state.messages = []
    st.session_state.status = "Interpreting question"
    st.session_state.error = None
    st.session_state.form_submitted = ({}) 
    st.session_state.question = "" 

def input_chat():
    # Initialize session state
    initialize_session_state()

    # Add custom CSS for the header and chat layout
    logo_path = "indigo_logo.png"
    logo_width = 120

    st.markdown(f"""
        <style>
        .chat-messages {{
            margin-bottom: 100px;
            padding-bottom: 20px;
        }}
        .input-container {{
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background-color: white;
            padding: 1rem;
            border-top: 1px solid #e0e0e0;
            z-index: 9999;
        }}
        .stButton button {{
            width: 100%;
        }}
        </style>

    """, unsafe_allow_html=True)

    st.markdown("---")

    # Create a container for chat messages
    chat_container = st.container()
    
    with chat_container:
        st.markdown('<div class="chat-messages">', unsafe_allow_html=True)
        # Display chat messages
        for message in st.session_state.messages:
            with st.chat_message(message["role"]):
                st.markdown(message["content"])
        st.markdown('</div>', unsafe_allow_html=True)

    # Create fixed bottom container for chat input
    st.markdown('<div class="input-container">', unsafe_allow_html=True)
    
    # Create two columns for the chat input and clear button
    col1, col2 = st.columns([6, 1])
    
    with col1:
        # Chat input
        if prompt := st.chat_input("What would you like to know?"):
            # Add user message to chat history
            st.session_state.messages.append({"role": "user", "content": prompt})
            
            # Display user message
            with st.chat_message("user"):
                st.markdown(prompt)
            
            # Simulate assistant response
            with st.chat_message("assistant"):
                response = f"Echo: {prompt}"  # Replace with actual response logic
                st.markdown(response)
                st.session_state.messages.append({"role": "assistant", "content": response})
            st.rerun()  # Rerun to update the display
    
    with col2:
        # Clear chat button
        if st.button("🗑️", help="Clear chat history"):
            clear_chat()
            st.rerun()
    
    st.markdown('</div>', unsafe_allow_html=True)

if __name__ == "__main__":
    input_chat() 