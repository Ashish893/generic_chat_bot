# Import python packages
import streamlit as st
import pandas as pd
from datetime import datetime

import json  # To handle JSON data
import time
from typing import Dict, List, Optional, Tuple, Union


st.header("PRISM AI DASHBOARD")
  

def get_data(session):    
    
    sql_query = f"""
        SELECT 
            BOOKING_FY,
            BOOKINGCHANNEL,
            COUNT(DISTINCT PAX_GUID) as CUSTOMERS,
            COUNT(DISTINCT TRIPID) as ANNUALTRIPS,
        FROM CUSTOMER_BOOKING_SUMMARY
        GROUP BY BOOKING_FY, BOOKINGCHANNEL
    """ 
    df = pd.read_sql(sql_query,session)
    return df


# Helper functions for data formatting and aggregation
def format_with_commas(number):
    return f"{number:,}"


def aggregate_data(df, freq):
    return df.groupby('BOOKING_FY').agg(
        Total_Customers=('CUSTOMERS', 'sum'),
        Total_Trips=('ANNUALTRIPS', 'sum')
    ).reset_index()


def create_chart(df_display, y, color, height, chart_type,chart_title): # Pass df_display as argument
    st.subheader(chart_title)
    if chart_type == 'Bar':
        st.bar_chart(df_display, x="BOOKING_FY", y=y, color=color, height=height)  # Use BOOKING_FY
    if chart_type == 'Area':
        st.area_chart(df_display, x="BOOKING_FY", y=y, color=color, height=height)  # Use BOOKING_FY


def get_filter_data(df,start_date,end_date, filter_col_list, filter_col_value):    
    # Filtering the data
    if start_date and end_date and filter_col_value !='None':
        mask = (df['BOOKING_FY'] >= str(start_date)) & (df['BOOKING_FY'] <= str(end_date)) & (df[filter_col_list] == str(filter_col_value))                        
        df_filtered = df.loc[mask]
    elif start_date and end_date and filter_col_value =='None':
        mask = (df['BOOKING_FY'] >= str(start_date)) & (df['BOOKING_FY'] <= str(end_date))
        df_filtered = df.loc[mask]        
    else:
        df_filtered = df
    return df_filtered


def get_widget(df,uniquekey):
    col = st.columns(5)
    with col[0]:
        start_date = st.selectbox("Start Fiscal Year", options= list(df['BOOKING_FY'].unique()),key=uniquekey+"_1")
    with col[1]:
        end_date = st.selectbox("End Fiscal Year",  options= list(df['BOOKING_FY'].unique()),key=uniquekey+"_2")
    with col[2]:
        agg_col_list = st.selectbox("Agg by Columns",  options=['None'] + list(df.columns.values),key=uniquekey+"_3")
    with col[3]:
        filter_col_list = st.selectbox("filter by Columns",  options=list(df.columns.values),key=uniquekey+"_4")
        new_col = st.columns(1)
        with new_col[0]:
            filter_col_value = st.selectbox(f"""sample value of {filter_col_list}""",  options=['None'] + list(df[filter_col_list].iloc[-10:]),key=uniquekey+"_5")
    with col[4]:
        chart_selection = st.selectbox("Select a chart type",("Bar", "Area"),key=uniquekey+"_6")
    st.divider()                    
    return start_date, end_date, chart_selection, agg_col_list, filter_col_list, filter_col_value

def display_chart(df,chart_selection):
    # Display the chart
    cols = st.columns(2) #creating two columns for charts
    with cols[0]:
        create_chart(df, 'CUSTOMERS', '#FF4A3D', 400, chart_selection,"CUSTOMERS")  # Pass df_filtered
    with cols[1]:        
        create_chart(df, 'ANNUALTRIPS', '#FF4A3D', 400, chart_selection,"ANNUAL TRIP")  # Pass df_filtered


def display_data(df_filtered, agg_col_list, uniquekey):
    # Use tabs for different data views
    data_tabs = st.tabs(["Filtered Data", "Pivot Table", "Aggregated Data"]) # Added tab
        
    # Show the data
    with data_tabs[0]:
      st.dataframe(df_filtered)    
    
    # Pivot
    with data_tabs[1]:
        col = st.columns(3)
        with col[0]:
            index_col = st.selectbox("select index col", options= ['None'] + list(df_filtered.columns.values),key=uniquekey+"_7")
        with col[1]:
            pivot_col = st.selectbox("select pivot col",  options= ['None'] + list(df_filtered),key=uniquekey+"_8")
        with col[2]:        
            value_col = st.selectbox("select value col",  options= ['None'] + list(df_filtered),key=uniquekey+"_9")
        if index_col == 'None' or pivot_col == 'None' or value_col == 'None':
            st.write("please select the values to generate pivot table ")
        else:
            pivot_df = df_filtered.pivot_table(index=index_col, columns=pivot_col, values=[value_col], aggfunc='sum')
            st.dataframe(pivot_df)
        
    # Aggregated Data
    with data_tabs[2]:
        if agg_col_list == 'None':
          agg_df = df_filtered.groupby('BOOKING_FY').agg(
              Total_Customers=('CUSTOMERS', 'sum'),
              Total_Trips=('ANNUALTRIPS', 'sum'),
              Total_Bookings = ('BOOKINGCHANNEL','count')
          ).reset_index()
          st.dataframe(agg_df)
        else:
          agg_df = df_filtered.groupby(agg_col_list).agg(
              Total_Customers=('CUSTOMERS', 'sum'),
              Total_Trips=('ANNUALTRIPS', 'sum'),
              Total_Bookings = ('BOOKINGCHANNEL','count')
          ).reset_index()
          st.dataframe(agg_df)    
        

    # with data_tabs[3]:
    #     cortexmain()      
    

def add_kpis():
    # KPI Cards
    kpi1, kpi2, kpi3 = st.columns(3)
    return kpi1, kpi2, kpi3


def get_total(df_filtered,kpi1, kpi2, kpi3, uniquekey):
    if not df_filtered.empty:
        total_customers = df_filtered['CUSTOMERS'].sum()
        avg_trips = df_filtered['ANNUALTRIPS'].mean()
    else:
        total_customers = 0
        avg_trips = 0
        total_gender = 0
    cols = st.columns(2)
    with cols[0]:
        kpi1.metric(label="Total Customers", value=format_with_commas(total_customers))
    with cols[1]:
        kpi2.metric(label="Average Trips", value=format_with_commas(avg_trips))
    st.divider()



# Initialize a Snowpark session for executing queries
# session = get_active_session()

# data_tabs = st.tabs(["Customers by BookingChannel","Customers by Contact"]) # Added tab
# with data_tabs[0]:
#     uniquekey=str(data_tabs[0])
#     df=get_data(session)
#     start_date,end_date,chart_selection,agg_col_list, filter_col_list, filter_col_value = get_widget(df,uniquekey)
#     df_filtered=get_filter_data(df,start_date,end_date, filter_col_list, filter_col_value)
#     kpi1, kpi2, kpi3=add_kpis()
#     get_total(df_filtered,kpi1, kpi2, kpi3,uniquekey)
#     display_chart(df_filtered,chart_selection)
#     display_data(df_filtered, agg_col_list,uniquekey)
# with data_tabs[1]:
#     uniquekey=str(data_tabs[1])
#     df=get_data(session)
#     start_date,end_date,chart_selection,agg_col_list, filter_col_list, filter_col_value = get_widget(df,uniquekey)
#     df_filtered=get_filter_data(df,start_date,end_date, filter_col_list, filter_col_value)
#     kpi1, kpi2, kpi3=add_kpis()
#     get_total(df_filtered,kpi1, kpi2, kpi3,uniquekey)
#     display_chart(df_filtered,chart_selection)
#     display_data(df_filtered, agg_col_list,uniquekey)

# st.html(
# """
# <style>
# .stPopover {
#   position: fixed;
#   bottom: 10px;
#   right: 10px;
# }

# </style>
# """
# )

# with st.popover("Ask Cortex"):
#   prompt = st.chat_input("Say something")
#   if prompt:
#     st.write(f"User has sent the following prompt: {prompt}")

 