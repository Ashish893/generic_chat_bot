# Public Docs: https://docs.snowflake.com/en/user-guide/snowflake-cortex/cortex-analyst/rest-api
# This demo is not supported in SiS. You must run this streamlit locally.

import json
import re
from typing import Any, Generator, Iterator

import pandas
import pandas as pd
import requests
import snowflake.connector
import sseclient
import streamlit as st
import spcs_helpers
# import dashboard



STAGE = "RAW_DATA"
FILE = "sales_semantic_model.yml"
@st.cache_resource
def connect_to_snowflake():
    return spcs_helpers.session()
st.session_state.CONN = spcs_helpers.connection()


#session = connect_to_snowflake()
if "CONN" not in st.session_state or st.session_state.CONN is None:
    # For troubleshooting your snowflake connection see https://docs.snowflake.com/en/developer-guide/python-connector/python-connector-connect
    st.session_state.CONN = connect_to_snowflake()

session = st.session_state.CONN
def get_conversation_history() -> list[dict[str, Any]]:
    messages = []
    for msg in st.session_state.messages:
        m: dict[str, Any] = {}
        if msg["role"] == "user":
            m["role"] = "user"
        else:
            m["role"] = "analyst"
        text_content = "\n".join([c for c in msg["content"] if isinstance(c, str)])
        m["content"] = [{"type": "text", "text": text_content}]
        messages.append(m)
    return messages


def send_message() -> requests.Response:
    """Calls the REST API and returns a streaming client."""
    request_body = {
        "messages": get_conversation_history(),
        "semantic_model_file": f"@{st.session_state.CONN.database}.{st.session_state.CONN.schema}.{STAGE}/{FILE}",
        "stream": True,
    }
    resp = requests.post(
        url=f"https://{st.session_state.CONN.host}/api/v2/cortex/analyst/message",
        # url="https://ut10439.ap-northeast-1.snowflakecomputing.com/api/v2/cortex/analyst/message",
        json=request_body,
        headers={
            "Authorization": f'Snowflake Token="{st.session_state.CONN.rest.token}"',
            "Content-Type": "application/json",
        },
        stream=True,
    )
    if resp.status_code < 400:
        return resp  # type: ignore
    else:
        raise Exception(f"Failed request with status {resp.status_code}: {resp.text}")


def stream(events: Iterator[sseclient.Event]) -> Generator[Any, Any, Any]:
    prev_index = -1
    prev_type = ""
    prev_suggestion_index = -1
    while True:
        event = next(events, None)
        if not event:
            return
        data = json.loads(event.data)
        new_content_block = event.event != "message.content.delta" or data["index"] != prev_index

        if prev_type == "sql" and new_content_block:
            # Close sql markdown once sql section finishes.
            yield "\n```\n\n"
        match event.event:
            case "message.content.delta":
                match data["type"]:
                    case "sql":
                        if new_content_block:
                            # Add sql markdown when we enter a new sql block.
                            yield "```sql\n"
                        yield data["statement_delta"]
                    case "text":
                        yield data["text_delta"]
                    case "suggestions":
                        if new_content_block:
                            # Add a suggestions header when we enter a new suggestions block.
                            yield "\nHere are some example questions you could ask:\n\n"
                            yield "\n- "
                        elif (
                            prev_suggestion_index != data["suggestions_delta"]["index"]
                        ):
                            yield "\n- "
                        yield data["suggestions_delta"]["suggestion_delta"]
                        prev_suggestion_index = data["suggestions_delta"]["index"]
                prev_index = data["index"]
                prev_type = data["type"]
            case "status":
                st.session_state.status = data["status_message"]
                # We return here to allow the spinner to update with the latest status, but this method will be
                #  called again for the next iteration
                return
            case "error":
                st.session_state.error = data
                return


def display_df(df: pandas.DataFrame) -> None:
    if len(df.index) > 1:
        data_tab, line_tab, bar_tab = st.tabs(["Data", "Line Chart", "Bar Chart"])
        data_tab.dataframe(df)
        if len(df.columns) > 1:
            df = df.set_index(df.columns[0])
        with line_tab:
            st.line_chart(df)
        with bar_tab:
            st.bar_chart(df)
    else:
        st.dataframe(df)


def process_message(prompt: str) -> None:
    """Processes a message and adds the response to the chat."""
    st.session_state.messages.append({"role": "user", "content": [prompt]})
    with st.chat_message("user"):
        st.markdown(prompt)

    accumulated_content = []
    with st.chat_message("assistant"):
        with st.spinner("Sending request..."):
            response = send_message()
        st.markdown(
            f"```request_id: {response.headers.get('X-Snowflake-Request-Id')}```"
        )
        events = sseclient.SSEClient(response).events()  # type: ignore
        while st.session_state.status.lower() != "done":
            with st.spinner(st.session_state.status):
                written_content = st.write_stream(stream(events))
                accumulated_content.append(written_content)
            if st.session_state.error:
                st.error(
                    f"Error while processing request:\n {st.session_state.error}",
                    icon="🚨",
                )
                accumulated_content.append(Exception(st.session_state.error))
                st.session_state.error = None
                st.session_state.status = "Interpreting question"
                st.session_state.messages.pop()
                return
            pattern = r"```sql\s*(.*?)\s*```"
            sql_blocks = re.findall(pattern, written_content, re.DOTALL | re.IGNORECASE)
            if sql_blocks:
                for sql_query in sql_blocks:
                    with st.spinner("Executing Query"):
                        df = pd.read_sql(sql_query, st.session_state.CONN)
                        accumulated_content.append(df)
                        display_df(df)
    st.session_state.status = "Interpreting question"
    st.session_state.messages.append(
        {"role": "analyst", "content": accumulated_content}
    )


def show_conversation_history() -> None:
    for message in st.session_state.messages:
        chat_role = "assistant" if message["role"] == "analyst" else "user"
        with st.chat_message(chat_role):
            for content in message["content"]:
                if isinstance(content, pd.DataFrame):
                    display_df(content)
                elif isinstance(content, Exception):
                    st.error(f"Error while processing request:\n {content}", icon="🚨")
                else:
                    st.write(content)



markdown_style = """
<style>
.custom-popover {
  position: fixed;
  bottom: 10px;
  left: 10px;
  background-color: white;
  border: 1px solid #ccc;
  padding: 10px;
  box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.1);
  border-radius: 5px;
  z-index: 1000; /* Ensure it's on top */
}
</style>
"""
st.markdown(markdown_style, unsafe_allow_html=True)


# Use a container to hold your chat elements
popover_content = st.container()
st.title("💬 Chat with RAAS Sales Data AI")
 
# if st.button("Reset conversation") or "messages" not in st.session_state:
#     st.session_state.messages = []
#     st.session_state.suggestions = []
#     st.session_state.active_suggestion = None

if "messages" not in st.session_state:
    st.session_state.messages = []
    st.session_state.status = "Interpreting question"
    st.session_state.error = None
if user_input := st.chat_input("What is your question?"):    
    show_conversation_history()    
    process_message(prompt=user_input)    


# with st.popover("Ask Prism",):    
#     st.image("indigo_logo.png", caption="AI Assistant", width=500)
#     if user_input := st.chat_input("What is your question?"):
#         show_conversation_history()    
#         process_message(prompt=user_input)
    
# data_tabs = st.tabs(["Customers by BookingChannel","Customers by Contact"]) # Added tab
# with data_tabs[0]:
#     uniquekey=str(data_tabs[0])
#     df=dashboard.get_data(st.session_state.CONN)
#     start_date,end_date,chart_selection,agg_col_list, filter_col_list, filter_col_value = dashboard.get_widget(df,uniquekey)
#     df_filtered=dashboard.get_filter_data(df,start_date,end_date, filter_col_list, filter_col_value)
#     kpi1, kpi2, kpi3=dashboard.add_kpis()
#     dashboard.get_total(df_filtered,kpi1, kpi2, kpi3,uniquekey)
#     dashboard.display_chart(df_filtered,chart_selection)
#     dashboard.display_data(df_filtered, agg_col_list,uniquekey)    