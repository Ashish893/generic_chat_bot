import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import base64
import os
import traceback

user='chat_test_user'   

# CSS Styles
def get_chat_styles():
    try:
        return """
            <style>
            .chat-messages {
                margin-bottom: 100px;
                padding-bottom: 20px;
            }
            .input-container {
                position: fixed;
                bottom: 0;
                left: 0;
                right: 0;
                background-color: white;
                padding: 1rem;
                border-top: 1px solid #e0e0e0;
                z-index: 9999;
            }
            .stButton button {
                width: 100%;
            }
            .user-bubble { 
                background-color: #dcf8c6; 
                padding: 10px; 
                border-radius: 10px; 
                max-width: 75%; 
                margin-left: auto; 
                margin-bottom: 5px; 
            }
            .bot-bubble { 
                background-color: #fff; 
                padding: 10px; 
                border-radius: 10px; 
                max-width: 75%; 
                margin-right: auto; 
                margin-bottom: 5px; 
                border: 1px solid #ccc; 
            }
            .timestamp { 
                font-size: 10px; 
                color: gray; 
                text-align: right; 
                margin-top: 2px; 
            }
            .custom-header { 
                display: flex; 
                align-items: center; 
                gap: 10px; 
            }
            .custom-header img { 
                width: 40px; 
            }
            </style>
        """
    except Exception as e:
        st.error(f"Error in get_chat_styles: {str(e)}")
        st.error(traceback.format_exc())
        return ""

def get_header_styles():
    try:
        return """
            <style>
            .main-header {
                background-color: #2436A2;
                padding: 0.5rem 1rem;
                display: flex;
                align-items: center;
                margin: -1rem -1rem 1rem -1rem;
                height: 80px;
                color: white;
                font-size: 1.2rem;
                font-weight: 600;
            }
            .logo-container {
                display: flex;
                align-items: center;
            }
            .logo-container img {
                max-height: 60px;
                width: auto;
                margin-right: 0.75rem;
            }
            .text-container {
                display: flex;
                flex-direction: column;
                justify-content: center;
            }
            .title-text {
                font-size: 1.2rem;
                font-weight: 600;
            }
            .welcome-text {
                font-size: 0.85rem;
                font-weight: 300;
                margin-top: 0.2rem;
            }
            </style>
        """
    except Exception as e:
        st.error(f"Error in get_header_styles: {str(e)}")
        st.error(traceback.format_exc())
        return ""

# Session State Management
def initialize_session_state():
    try:
        if 'messages' not in st.session_state:
            st.session_state.messages = []
            st.session_state.status = "Interpreting question"
            st.session_state.error = None
            st.session_state.form_submitted = ({}) 
            st.session_state.question = ""   

        if "show_text_input" not in st.session_state:
            st.session_state.show_text_input = False         
        if 'question' not in st.session_state:
            st.session_state.question = ""          
    except Exception as e:
        st.error(f"Error in initialize_session_state: {str(e)}")
        st.error(traceback.format_exc())

def clear_chat():
    try:
        st.session_state.messages = []
        st.session_state.status = "Interpreting question"
        st.session_state.error = None
        st.session_state.form_submitted = ({}) 
        st.session_state.question = "" 
    except Exception as e:
        st.error(f"Error in clear_chat: {str(e)}")
        st.error(traceback.format_exc())

# Header Component
def display_header():
    try:
        logo_path = "logo.png"
        if not os.path.exists(logo_path):
            st.error(f"Logo file not found at: {logo_path}")
            return

        with open(logo_path, "rb") as image_file:
            encoded_logo = base64.b64encode(image_file.read()).decode()

        st.markdown(get_header_styles(), unsafe_allow_html=True)
        st.markdown(f"""
            <div class="main-header">
                <div class="logo-container">
                    <img src="data:image/png;base64,{encoded_logo}" alt="Logo">
                    <div class="text-container">
                        <div class="title-text">Ask PRISM-SALES</div>
                    </div>
                </div>
            </div>
        """, unsafe_allow_html=True)
    except Exception as e:
        st.error(f"Error in display_header: {str(e)}")
        st.error(traceback.format_exc())

# Welcome Message Component
def display_welcome_message(user):
    try:
        if not user:
            st.error("User information is missing")
            return
            
        st.markdown(f"""
            <div class="custom-header">
                <strong><i>{user.split("@")[0].split(".")[0].capitalize()}</i>, Welcome to Ask PRISM! </strong> 
                Type your question below to interact with PRISM data.
            </div>
        """, unsafe_allow_html=True)
    except Exception as e:
        st.error(f"Error in display_welcome_message: {str(e)}")
        st.error(traceback.format_exc())

# Chat Interface Component
def display_chat_interface():
    try:
        st.markdown(get_chat_styles(), unsafe_allow_html=True)
        
        # Create two columns for the chat input and clear button
        col1, col2 = st.columns([6, 1])
        
        with col1:
            # Chat input
            if user_input := st.chat_input("How can I help you?", key="chat_input"):
                try:  
                    # Import here to avoid circular import
                    from app_analyst_raas_latest import process_message
                    process_message(prompt=user_input)  
                except Exception as e:
                    st.error(f"Error processing message: {str(e)}")
                    st.error(traceback.format_exc())
                    st.info("Something went wrong. To get back on track, please clear the chat")         
        
        with col2:
            # Clear chat button
            if st.button("🗑️", help="Clear chat history"):
                clear_chat()
                st.rerun()
    except Exception as e:
        st.error(f"Error in display_chat_interface: {str(e)}")
        st.error(traceback.format_exc())

# Main Application
def run_chat_app(user):
    try:
        # Initialize session state
        initialize_session_state()
        
        # Display header
        display_header()
        
        # Get user history and display welcome message
        try:
            # Import here to avoid circular import
            from app_analyst_raas_latest import get_user_history, history_sidebar, show_conversation_history
            
            user, prev_questions, monitoring_df = get_user_history(user)
            if not user:
                st.error("Failed to get user information")
                return
            display_welcome_message(user)
        except Exception as e:
            st.error(f"Error getting user history: {str(e)}")
            st.error(traceback.format_exc())
            return

        # Display sidebar history
        try:    
            history_sidebar(user, prev_questions, monitoring_df)
        except Exception as e:
            st.error(f"Error displaying sidebar history: {str(e)}")
            st.error(traceback.format_exc())
            return

        # Show conversation history
        try:    
            show_conversation_history()
        except Exception as e:
            st.error(f"Error showing conversation history: {str(e)}")
            st.error(traceback.format_exc())
            return

        # Display chat interface
        try:
            display_chat_interface()
        except Exception as e:
            st.error(f"Error displaying chat interface: {str(e)}")
            st.error(traceback.format_exc())
    except Exception as e:
        st.error(f"Critical error in run_chat_app: {str(e)}")
        st.error(traceback.format_exc())

if __name__ == "__main__":
    user='chat_test_user'   
    run_chat_app(user)
