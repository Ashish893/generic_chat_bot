import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import uuid
import altair as alt
from spcs_helpers.chart_utils import (
    create_chart1, create_chart2, create_chart3, create_chart4,
    create_chart5, create_chart6, create_chart7, create_chart8, create_chart9, create_chart10, generate_chart_code_for_dataframe
)
import base64
import os


def display_chart(df: pd.DataFrame, message_index: int) -> None:
    """
    Display a DataFrame with interactive chart options.
    
    Args:
        df (pd.DataFrame): The DataFrame to display
        message_index (int): Index of the message for unique keys
    """
    if df.empty:
        st.info("No data to display")
        return
    else:
        df_display = df.head(5000)
        # Display the DataFrame
        st.dataframe(df_display, use_container_width=True)

    # Generate a random key for unique widget keys
    random_key = str(uuid.uuid4())[:8]

    st.download_button(
        label="Download CSV",
        data=df_display.to_csv(index=False).encode('utf-8'),
        file_name='data.csv',
        mime='text/csv',
        key=f'download_csv_{random_key}'
    )
    
    # Create an Altair chart based on DataFrame content using predefined rules
    try:
        # Identify column types
        numeric_cols = [col for col in df_display.columns if pd.api.types.is_numeric_dtype(df_display[col])]
        date_cols = [col for col in df_display.columns if pd.api.types.is_datetime64_any_dtype(df_display[col])]
        text_cols = [col for col in df_display.columns if col not in numeric_cols and col not in date_cols]

        # Define available chart types based on data
        available_charts = []

        # Rule 1: Bar Chart by Date (1 date column + 1 numeric column)
        if len(date_cols) >= 1 and len(numeric_cols) >= 1:
            available_charts.append({
                'name': 'Bar Chart by Date',
                'required_columns': {
                    'date': date_cols,
                    'numeric': numeric_cols
                }
            })

        # Rule 2: Dual Axis Line Chart (1 date column + 2 numeric columns)
        if len(date_cols) >= 1 and len(numeric_cols) >= 2:
            available_charts.append({
                'name': 'Dual Axis Line Chart',
                'required_columns': {
                    'date': date_cols,
                    'numeric': numeric_cols
                }
            })

        # Rule 3: Stacked Bar Chart by Date (1 date column + 1 text column + 1 numeric column)
        if len(date_cols) >= 1 and len(text_cols) >= 1 and len(numeric_cols) >= 1:
            available_charts.append({
                'name': 'Stacked Bar Chart by Date',
                'required_columns': {
                    'date': date_cols,
                    'text': text_cols,
                    'numeric': numeric_cols
                }
            })

        # Rule 4: Multi-Series Line Chart (1 date column + 2+ text columns + 1 numeric column)
        if len(date_cols) >= 1 and len(text_cols) >= 2 and len(numeric_cols) >= 1:
            available_charts.append({
                'name': 'Multi-Series Line Chart',
                'required_columns': {
                    'date': date_cols,
                    'text': text_cols,
                    'numeric': numeric_cols
                }
            })

        # Rule 5: Scatter Chart (2 numeric columns + 1 text column)
        if len(numeric_cols) >= 2 and len(text_cols) >= 1:
            available_charts.append({
                'name': 'Scatter Chart',
                'required_columns': {
                    'numeric': numeric_cols,
                    'text': text_cols
                }
            })

        # Rule 6: Bubble Chart (3 numeric columns + 2 text columns)
        if len(numeric_cols) >= 3 and len(text_cols) >= 2:
            available_charts.append({
                'name': 'Bubble Chart',
                'required_columns': {
                    'numeric': numeric_cols,
                    'text': text_cols
                }
            })

        # Rule 7: Multi-Metric Bar Chart (3 numeric columns + 1 text column)
        if len(numeric_cols) >= 3 and len(text_cols) >= 1:
            available_charts.append({
                'name': 'Multi-Metric Bar Chart',
                'required_columns': {
                    'numeric': numeric_cols,
                    'text': text_cols
                }
            })

        # Rule 8: Multi-Dimensional Analysis (3+ numeric columns + 2+ text columns)
        if len(numeric_cols) >= 3 and len(text_cols) >= 2:
            available_charts.append({
                'name': 'Multi-Dimensional Analysis',
                'required_columns': {
                    'numeric': numeric_cols,
                    'text': text_cols
                }
            })

        # Rule 9: Bar Chart with Selectable X-Axis and Color (1 text column + 1 numeric column)
        if len(text_cols) >= 1 and len(numeric_cols) >= 1:
            available_charts.append({
                'name': 'Bar Chart with Selectable X-Axis and Color',
                'required_columns': {
                    'text': text_cols,
                    'numeric': numeric_cols
                }
            })

        # Rule 10: KPI Tiles (1-4 numeric columns)
        if len(numeric_cols) >= 1 and len(numeric_cols) <= 4:
            available_charts.append({
                'name': 'KPI Tiles',
                'required_columns': {
                    'numeric': numeric_cols
                }
            })

        # If no charts are available, show message and return
        if not available_charts:
            st.info("No suitable chart types available for this data")
            return

        # Chart selection
        chart_names = [chart['name'] for chart in available_charts]
        selected_chart_name = st.selectbox(
            "Select Chart Type",
            options=chart_names,
            key=f'chart_selector_{message_index}'
        )

        # Get the selected chart configuration
        selected_chart = next(chart for chart in available_charts if chart['name'] == selected_chart_name)

        if selected_chart_name == "Bar Chart by Date":
            # Get required columns
            date_col = st.selectbox(
                "Select Date Column",
                options=selected_chart['required_columns']['date'],
                key=f'date_col_{message_index}'
            )
            numeric_col = st.selectbox(
                "Select Numeric Column",
                options=selected_chart['required_columns']['numeric'],
                key=f'numeric_col_{message_index}'
            )

            # Create the chart
            df_agg = df_display.groupby(date_col)[numeric_col].sum().reset_index()
            chart = alt.Chart(df_agg).mark_bar().encode(
                x=alt.X(f'{date_col}:T', axis=alt.Axis(format='%Y-%m-%d')),
                y=alt.Y(f'{numeric_col}:Q'),
                tooltip=[
                    alt.Tooltip(f'{date_col}:T', format='%Y-%m-%d'),
                    alt.Tooltip(f'{numeric_col}:Q', format='.2f')
                ]
            ).properties(
                title=f'{numeric_col} by {date_col}'
            )
            st.altair_chart(chart, use_container_width=True)

        elif selected_chart_name == "Dual Axis Line Chart":
            date_col = st.selectbox(
                "Select Date Column",
                options=selected_chart['required_columns']['date'],
                key=f'date_col_{message_index}'
            )
            col1, col2 = st.columns(2)
            with col1:
                numeric_col1 = st.selectbox(
                    "Select First Numeric Column",
                    options=selected_chart['required_columns']['numeric'],
                    key=f'numeric_col1_{message_index}'
                )
            with col2:
                numeric_col2 = st.selectbox(
                    "Select Second Numeric Column",
                    options=[col for col in selected_chart['required_columns']['numeric'] if col != numeric_col1],
                    key=f'numeric_col2_{message_index}'
                )

            df_agg = df_display.groupby(date_col)[[numeric_col1, numeric_col2]].sum().reset_index()
            
            base = alt.Chart(df_agg).encode(
                x=alt.X(f'{date_col}:T', axis=alt.Axis(format='%Y-%m-%d'))
            )
            
            line1 = base.mark_line(color='blue').encode(
                y=alt.Y(f'{numeric_col1}:Q', axis=alt.Axis(title=numeric_col1)),
                tooltip=[alt.Tooltip(f'{date_col}:T', format='%Y-%m-%d'),
                        alt.Tooltip(f'{numeric_col1}:Q', format='.2f')]
            )
            
            line2 = base.mark_line(color='red').encode(
                y=alt.Y(f'{numeric_col2}:Q', axis=alt.Axis(title=numeric_col2, orient='right')),
                tooltip=[alt.Tooltip(f'{date_col}:T', format='%Y-%m-%d'),
                        alt.Tooltip(f'{numeric_col2}:Q', format='.2f')]
            )
            
            chart = alt.layer(line1, line2).resolve_scale(y='independent')
            st.altair_chart(chart, use_container_width=True)

        elif selected_chart_name == "Stacked Bar Chart by Date":
            date_col = st.selectbox(
                "Select Date Column",
                options=selected_chart['required_columns']['date'],
                key=f'date_col_{message_index}'
            )
            text_col = st.selectbox(
                "Select Grouping Column",
                options=selected_chart['required_columns']['text'],
                key=f'text_col_{message_index}'
            )
            numeric_col = st.selectbox(
                "Select Numeric Column",
                options=selected_chart['required_columns']['numeric'],
                key=f'numeric_col_{message_index}'
            )

            df_agg = df_display.groupby([date_col, text_col])[numeric_col].sum().reset_index()
            chart = alt.Chart(df_agg).mark_bar().encode(
                x=alt.X(f'{date_col}:T', axis=alt.Axis(format='%Y-%m-%d')),
                y=alt.Y(f'{numeric_col}:Q'),
                color=alt.Color(f'{text_col}:N'),
                tooltip=[
                    alt.Tooltip(f'{date_col}:T', format='%Y-%m-%d'),
                    alt.Tooltip(f'{text_col}:N'),
                    alt.Tooltip(f'{numeric_col}:Q', format='.2f')
                ]
            ).properties(
                title=f'{numeric_col} by {date_col} grouped by {text_col}'
            )
            st.altair_chart(chart, use_container_width=True)

        elif selected_chart_name == "Multi-Series Line Chart":
            date_col = st.selectbox(
                "Select Date Column",
                options=selected_chart['required_columns']['date'],
                key=f'date_col_{message_index}'
            )
            text_col1 = st.selectbox(
                "Select First Grouping Column",
                options=selected_chart['required_columns']['text'],
                key=f'text_col1_{message_index}'
            )
            text_col2 = st.selectbox(
                "Select Second Grouping Column",
                options=[col for col in selected_chart['required_columns']['text'] if col != text_col1],
                key=f'text_col2_{message_index}'
            )
            numeric_col = st.selectbox(
                "Select Numeric Column",
                options=selected_chart['required_columns']['numeric'],
                key=f'numeric_col_{message_index}'
            )

            df_agg = df_display.groupby([date_col, text_col1, text_col2])[numeric_col].sum().reset_index()
            chart = alt.Chart(df_agg).mark_line().encode(
                x=alt.X(f'{date_col}:T', axis=alt.Axis(format='%Y-%m-%d')),
                y=alt.Y(f'{numeric_col}:Q'),
                color=alt.Color(f'{text_col1}:N'),
                strokeDash=alt.StrokeDash(f'{text_col2}:N'),
                tooltip=[
                    alt.Tooltip(f'{date_col}:T', format='%Y-%m-%d'),
                    alt.Tooltip(f'{text_col1}:N'),
                    alt.Tooltip(f'{text_col2}:N'),
                    alt.Tooltip(f'{numeric_col}:Q', format='.2f')
                ]
            ).properties(
                title=f'{numeric_col} by {date_col} grouped by {text_col1} and {text_col2}'
            )
            st.altair_chart(chart, use_container_width=True)

        elif selected_chart_name == "Scatter Chart":
            col1, col2 = st.columns(2)
            with col1:
                numeric_col1 = st.selectbox(
                    "Select X-Axis Column",
                    options=selected_chart['required_columns']['numeric'],
                    key=f'numeric_col1_{message_index}'
                )
            with col2:
                numeric_col2 = st.selectbox(
                    "Select Y-Axis Column",
                    options=[col for col in selected_chart['required_columns']['numeric'] if col != numeric_col1],
                    key=f'numeric_col2_{message_index}'
                )
            text_col = st.selectbox(
                "Select Color Grouping Column",
                options=selected_chart['required_columns']['text'],
                key=f'text_col_{message_index}'
            )

            chart = alt.Chart(df_display).mark_circle().encode(
                x=alt.X(f'{numeric_col1}:Q'),
                y=alt.Y(f'{numeric_col2}:Q'),
                color=alt.Color(f'{text_col}:N'),
                tooltip=[
                    alt.Tooltip(f'{numeric_col1}:Q', format='.2f'),
                    alt.Tooltip(f'{numeric_col2}:Q', format='.2f'),
                    alt.Tooltip(f'{text_col}:N')
                ]
            ).properties(
                title=f'{numeric_col2} vs {numeric_col1} grouped by {text_col}'
            )
            st.altair_chart(chart, use_container_width=True)

        elif selected_chart_name == "Bubble Chart":
            col1, col2, col3 = st.columns(3)
            with col1:
                numeric_col1 = st.selectbox(
                    "Select X-Axis Column",
                    options=selected_chart['required_columns']['numeric'],
                    key=f'numeric_col1_{message_index}'
                )
            with col2:
                numeric_col2 = st.selectbox(
                    "Select Y-Axis Column",
                    options=[col for col in selected_chart['required_columns']['numeric'] if col != numeric_col1],
                    key=f'numeric_col2_{message_index}'
                )
            with col3:
                numeric_col3 = st.selectbox(
                    "Select Size Column",
                    options=[col for col in selected_chart['required_columns']['numeric'] if col not in [numeric_col1, numeric_col2]],
                    key=f'numeric_col3_{message_index}'
                )
            
            text_col1 = st.selectbox(
                "Select Color Grouping Column",
                options=selected_chart['required_columns']['text'],
                key=f'text_col1_{message_index}'
            )
            text_col2 = st.selectbox(
                "Select Shape Grouping Column",
                options=[col for col in selected_chart['required_columns']['text'] if col != text_col1],
                key=f'text_col2_{message_index}'
            )

            chart = alt.Chart(df_display).mark_circle().encode(
                x=alt.X(f'{numeric_col1}:Q'),
                y=alt.Y(f'{numeric_col2}:Q'),
                size=alt.Size(f'{numeric_col3}:Q'),
                color=alt.Color(f'{text_col1}:N'),
                shape=alt.Shape(f'{text_col2}:N'),
                tooltip=[
                    alt.Tooltip(f'{numeric_col1}:Q', format='.2f'),
                    alt.Tooltip(f'{numeric_col2}:Q', format='.2f'),
                    alt.Tooltip(f'{numeric_col3}:Q', format='.2f'),
                    alt.Tooltip(f'{text_col1}:N'),
                    alt.Tooltip(f'{text_col2}:N')
                ]
            ).properties(
                title=f'{numeric_col2} vs {numeric_col1} with {numeric_col3} as size'
            )
            st.altair_chart(chart, use_container_width=True)

        elif selected_chart_name == "Multi-Metric Bar Chart":
            text_col = st.selectbox(
                "Select X-Axis Column",
                options=selected_chart['required_columns']['text'],
                key=f'text_col_{message_index}'
            )
            numeric_cols = st.multiselect(
                "Select Numeric Columns",
                options=selected_chart['required_columns']['numeric'],
                default=selected_chart['required_columns']['numeric'][:3],
                key=f'numeric_cols_{message_index}'
            )

            if numeric_cols:
                df_melted = pd.melt(df_display, id_vars=[text_col], value_vars=numeric_cols)
                chart = alt.Chart(df_melted).mark_bar().encode(
                    x=alt.X(f'{text_col}:N'),
                    y=alt.Y('value:Q'),
                    color=alt.Color('variable:N'),
                    tooltip=[
                        alt.Tooltip(f'{text_col}:N'),
                        alt.Tooltip('variable:N'),
                        alt.Tooltip('value:Q', format='.2f')
                    ]
                ).properties(
                    title=f'Multiple Metrics by {text_col}'
                )
                st.altair_chart(chart, use_container_width=True)

        elif selected_chart_name == "Multi-Dimensional Analysis":
            text_col1 = st.selectbox(
                "Select First Grouping Column",
                options=selected_chart['required_columns']['text'],
                key=f'text_col1_{message_index}'
            )
            text_col2 = st.selectbox(
                "Select Second Grouping Column",
                options=[col for col in selected_chart['required_columns']['text'] if col != text_col1],
                key=f'text_col2_{message_index}'
            )
            numeric_cols = st.multiselect(
                "Select Numeric Columns",
                options=selected_chart['required_columns']['numeric'],
                default=selected_chart['required_columns']['numeric'][:3],
                key=f'numeric_cols_{message_index}'
            )

            if numeric_cols:
                df_melted = pd.melt(df_display, id_vars=[text_col1, text_col2], value_vars=numeric_cols)
                chart = alt.Chart(df_melted).mark_bar().encode(
                    x=alt.X(f'{text_col1}:N'),
                    y=alt.Y('value:Q'),
                    color=alt.Color(f'{text_col2}:N'),
                    column=alt.Column('variable:N'),
                    tooltip=[
                        alt.Tooltip(f'{text_col1}:N'),
                        alt.Tooltip(f'{text_col2}:N'),
                        alt.Tooltip('variable:N'),
                        alt.Tooltip('value:Q', format='.2f')
                    ]
                ).properties(
                    title=f'Multi-Dimensional Analysis'
                )
                st.altair_chart(chart, use_container_width=True)

        elif selected_chart_name == "Bar Chart with Selectable X-Axis and Color":
            # Get required columns
            text_cols = selected_chart['required_columns']['text']
            numeric_cols = selected_chart['required_columns']['numeric']

            # Generate a unique key for this chart instance
            chart_key = f"bar_chart_{message_index}_{random_key}"

            # First select the numeric column
            numeric_col = st.selectbox(
                "Select Numeric Column",
                options=numeric_cols,
                key=f'numeric_col_{chart_key}'
            )

            # Then select x-axis and color columns
            col1, col2 = st.columns(2)
            with col1:
                x_col = st.selectbox(
                    "Select X-Axis Column",
                    options=text_cols,
                    key=f'x_col_{chart_key}'
                )
            with col2:
                # Filter out the selected x-axis column from color options
                remaining_cols = [col for col in text_cols if col != x_col]
                if remaining_cols:
                    color_col = st.selectbox(
                        "Select Color Grouping Column",
                        options=remaining_cols,
                        key=f'color_col_{chart_key}'
                    )
                else:
                    st.warning("No columns available for color grouping")
                    return

            # Create the chart with proper grouping
            try:
                # Group by both x-axis and color columns
                df_agg = df_display.groupby([x_col, color_col])[numeric_col].sum().reset_index()
                
                # Create the chart
                chart = alt.Chart(df_agg).mark_bar().encode(
                    x=alt.X(f'{x_col}:N', title=x_col),
                    y=alt.Y(f'{numeric_col}:Q', title=numeric_col),
                    color=alt.Color(f'{color_col}:N', title=color_col),
                    tooltip=[
                        alt.Tooltip(f'{x_col}:N', title=x_col),
                        alt.Tooltip(f'{color_col}:N', title=color_col),
                        alt.Tooltip(f'{numeric_col}:Q', format='.2f', title=numeric_col)
                    ]
                ).properties(
                    title=f'{numeric_col} by {x_col} grouped by {color_col}'
                )
                st.altair_chart(chart, use_container_width=True, key=f'chart_{chart_key}')
            except Exception as e:
                st.info(f"Error creating chart: {str(e)}")
                st.write("Debug information:")
                st.write("Selected columns:", [x_col, color_col, numeric_col])
                st.write("DataFrame columns:", df_display.columns.tolist())
                st.write("Grouped data shape:", df_agg.shape if 'df_agg' in locals() else "Not created")

        elif selected_chart_name == "KPI Tiles":
            numeric_cols = st.multiselect(
                "Select KPI Metrics",
                options=selected_chart['required_columns']['numeric'],
                default=selected_chart['required_columns']['numeric'][:4],
                key=f'numeric_cols_{message_index}'
            )

            if numeric_cols:
                cols = st.columns(len(numeric_cols))
                for idx, col in enumerate(numeric_cols):
                    with cols[idx]:
                        value = df_display[col].sum()
                        st.metric(
                            label=col,
                            value=f"{value:,.2f}"
                        )

    except Exception as e:
        st.info(f"This chart is not supported for this data: {str(e)}")


def generate_sample_data():
    # Set random seed for reproducibility
    np.random.seed(42)
    
    # Generate dates for the last 30 days
    dates = [datetime.now() - timedelta(days=x) for x in range(30)]
    
    # Generate sample data
    data = {
        'date': dates * 3,  # 3 sectors
        'sector': ['Domestic', 'International', 'Cargo'] * 30,
        'passenger_count': np.random.randint(100, 1000, size=90),
        'revenue': np.random.uniform(1000, 10000, size=90),
        'flight_count': np.random.randint(5, 50, size=90),
        # 'aircraft_type': np.random.choice(['Boeing 737', 'Airbus A320', 'Boeing 787'], size=90),
        # 'route': np.random.choice(['Route A', 'Route B', 'Route C', 'Route D'], size=90)
    }
    
    # Create DataFrame
    df = pd.DataFrame(data)
    
    # Convert date to datetime
    df['date'] = pd.to_datetime(df['date'])
    
    return df

def main():
    logo_path = "indigo_logo.png"
    logo_width = 120

    st.markdown(f"""
        <style>
        .main-header {{
            background-color: #0F4C81;  /* Indigo's brand blue color */
            padding: 0.5rem 1rem;
            display: flex;
            align-items: center;
            margin: -1rem -1rem 1rem -1rem;
            height: 80px;
            position: relative;
            overflow: hidden;
            color: white;
            font-size: 1.5rem;
            font-weight: 600;
        }}
        .logo-container {{
            display: flex;
            align-items: center;
            height: 100%;
            padding-left: 1rem;
        }}
        .logo-container img {{
            height: auto;
            max-height: 60px;
            width: auto;
            max-width: {logo_width}px;
        }}
        </style>

        <div class="main-header">
            <div class="logo-container">
                <img src="data:image/png;base64,{base64.b64encode(open(logo_path, "rb").read()).decode()}" alt="Logo">
            </div>
            <div style="margin-left: 1rem;">Welcome to Indigo Dashboard</div>
        </div>
    """, unsafe_allow_html=True)

    
    st.markdown("---")  # Add a separator line
    
    # Generate sample data
    df = generate_sample_data()
    
    # Display the DataFrame with charts
    display_chart(df,0)

if __name__ == "__main__":
    main() 