import os
import snowflake.connector
from snowflake.snowpark import Session
snowflake.connector.paramstyle = 'qmark'
def connection() -> snowflake.connector.SnowflakeConnection:
    if os.path.isfile("/snowflake/session/token"):
        creds = {
            'host': os.getenv('SNOWFLAKE_HOST'),
            'port': os.getenv('SNOWFLAKE_PORT'),
            'protocol': "https",
            'account': os.getenv('SNOWFLAKE_ACCOUNT'),
            'authenticator': "oauth",
            'token': open('/snowflake/session/token', 'r').read(),
            'warehouse': os.getenv('SNOWFLAKE_WAREHOUSE'),
            'database': os.getenv('SNOWFLAKE_DATABASE'),
            'schema': os.getenv('SNOWFLAKE_SCHEMA'),
            'client_session_keep_alive': True
        }
    else:
        creds = {
            'account': '<account_locator>.central-india.privatelink',
            'user': 'chat_test_user',
            'role': 'CORTEX_USER_ROLE',
            'warehouse': 'DE_DS_WH',
            'database': 'CORTEX_ANALYST_DEMO',
            'schema': 'REVENUE_TIMESERIES',
            'client_session_keep_alive': True,
            'private_key_file': '/app/rsa_key.p8',
            'private_key_file_pwd':'xxxxx@2025!',            
        }
  

    connection = snowflake.connector.connect(**creds)
    return connection

def session() -> Session:
    return Session.builder.configs({"connection": connection()}).create()